module.exports = {
    download(response, apiConfig, frame) {
        frame.response = response;
    }
};
